export const DB_CONFIG = {
    host: 'localhost',
    port: 5432,
    user: 'postgres',
    pass: '1234',
    db: 'dc',
    dialect: 'postgres'
}