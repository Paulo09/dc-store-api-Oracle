import db from "../model/index.js"

const Produto = db.produto

export const produtoController ={
    // Cria um produto
    create:  (req,res) => {
        //criar o produto
        if(!req.body.nome){
           res.findByStatus(400).send({
                message:"O nome não pode ser vazio!!!"
           })
        }
          
        const {nome, categoria, descricao, desconto, precoAntes,precoDepois, ativo} = req.body

        const produto = {nome, categoria, descricao, desconto, precoAntes,precoDepois, ativo}
        
        Produto.create(produto)
        .then(data => {
            res.send(data);
        })
        .catch(e => {
            res.status(500).send({
                message: e.message || "Ocorreu um erro ao salvar o Produto!!!"
            })
        })
    },

    findById:  (req,res) => {
        //criar o produto


    },


    findAll:  (req,res) => {
        //criar o produto


    },



    findByStatus:  (req,res) => {
        //criar o produto


    },


    update:  (req,res) => {
        //criar o produto


    },
    
    deleteById:  (req,res) => {
        //criar o produto


    },

    deleteAll:  (req,res) => {
        //criar o produto


    },
}