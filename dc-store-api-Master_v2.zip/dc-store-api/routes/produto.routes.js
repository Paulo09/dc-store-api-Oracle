import express from "express"
import { produtoController } from "../Controller/produto.controller.js"

export const routeProduto = (app) => {


    const router = express.Router()

    // Salva  um novo produto BD
    router.post('/', produtoController.create)

    // Buscar todos os produtos
    router.get('/', produtoController.findAll)

    // Buscar por id
    router.get('/:id', produtoController.findById)

    //Buscar pelo status
    router.get('/:status', produtoController.findByStatus)

    //Atualizar um produto
    router.get('/:id', produtoController.update)

    // Deletar um produto
    router.delete('/:id', produtoController.deleteById)

    //Deletar todos os produtos
    router.delete('/', produtoController.deleteAll)

    app.use('/api/produto', router)
}